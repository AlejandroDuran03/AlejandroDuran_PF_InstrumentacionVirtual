#include "project.h"
#include <stdbool.h>

bool b_serial=false;
unsigned char caracter=0;

CY_ISR(interruptUART)
{
    caracter=Serial_GetChar();
    Serial_PutChar(caracter);
    b_serial=true;
}
int main(void)
{
    CyGlobalIntEnable;
isrUART_StartEx(interruptUART);
Serial_Start();

    for(;;)
    {
        if(b_serial)
        {
            b_serial=false;
            switch(caracter)
            {
                case 'M':
                Control_Write(0x01);
                break;
                case 'E':
                Control_Write(0x02);
                break;
                case 'N':
                Control_Write(0x03);
                break;
                case 'S':
                Control_Write(0x04);
                break;
                case 'A':
                Control_Write(0x05);
                break;
                case 'L':
                Control_Write(0x06);
                break;
                case 'C':
                Control_Write(0x07);
                break;
                case 'P':
                Control_Write(0x00);
                break;
            } 
        }
    }
}